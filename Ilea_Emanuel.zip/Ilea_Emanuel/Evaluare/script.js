

document.getElementById("util").ondblclick = function() {myFunction()};

function myFunction() {
 
  document.getElementById("img1").style.visibility="hidden";
  document.getElementById("img2").style.visibility="hidden";
  document.getElementById("img3").style.visibility="hidden";
  document.getElementById("slideshow-container").style.visibility="visible";
  }

var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides, 3000);
}